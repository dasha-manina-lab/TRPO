#include <QtTest>
#include <QString>
#include <chrono>
#include <thread>

class TestSample : public QObject
{
  Q_OBJECT
private:
  int x = 0;
  QString s;
private slots:
  void initTestCase();
  void cleanupTestCase();
  void test_succeed();
  void test_fail();
  void test_compare_pass();
  void test_compare_fail();
  void test_verify();
  void test_benchmark();
};

void TestSample::initTestCase()
{
  x = 10;
  s = "control value";
}

void TestSample::cleanupTestCase()
{
  s.clear();
  x = 0;
}

void TestSample::test_succeed()
{
  QVERIFY(true);
}

void TestSample::test_fail()
{
  QFAIL("Test failed");
}

void TestSample::test_compare_pass()
{
  const QString value = "control value";
  QCOMPARE(value, s);
}

void TestSample::test_compare_fail()
{
  const QString value = "Control value";
  QCOMPARE(value, s);
}

void TestSample::test_verify()
{
  QVERIFY(x > 0);
}

void TestSample::test_benchmark()
{
  QBENCHMARK
  {
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
  }
}

QTEST_APPLESS_MAIN(TestSample)
#include "tst_sample.moc"
