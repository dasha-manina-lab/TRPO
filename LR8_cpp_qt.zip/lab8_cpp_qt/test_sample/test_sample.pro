TEMPLATE = app
TARGET = test_sample
QT += core testlib
QT -= gui
CONFIG += console testcase c++17 debug_and_release build_all
CONFIG -= app_bundle

SOURCES += tst_sample.cpp
DISTFILES += .astylerc

CONFIG(debug, debug|release) {
    DESTDIR = $$OUT_PWD/debug
    OBJECTS_DIR = $$OUT_PWD/.obj/debug
    MOC_DIR = $$OUT_PWD/.moc/debug
} else {
    DESTDIR = $$OUT_PWD/release
    OBJECTS_DIR = $$OUT_PWD/.obj/release
    MOC_DIR = $$OUT_PWD/.moc/release
}
