#ifndef PRIMELISTLIB_H
#define PRIMELISTLIB_H

#include <vector>

// Return all prime numbers in the closed interval [l, r].
// Requires 1 <= l < r; throws std::out_of_range for invalid bounds.
std::vector<int> primelist(int l, int r);

#endif // PRIMELISTLIB_H
