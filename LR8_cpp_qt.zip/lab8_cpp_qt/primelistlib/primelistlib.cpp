// Проверка пересборки библиотеки
// Проверка пересборки библиотеки2

#include "primelistlib.h"

#include <algorithm>
#include <stdexcept>

namespace
{
void validateBounds(int a, int b)
{
  if(a <= 0)
  {
    throw std::out_of_range("Invalid A: the lower bound must be a natural number (A >= 1).");
  }
  if(b <= 0)
  {
    throw std::out_of_range("Invalid B: the upper bound must be a natural number (B >= 1).");
  }
  if(b <= a)
  {
    throw std::out_of_range("Invalid B: the upper bound must be strictly greater than A.");
  }
}

bool isprime(int n)
{
  if(n < 2)
  {
    return false;
  }
  // Division avoids overflow in i * i for large int values.
  for(int i = 2; i <= n / i; ++i)
    if(n % i == 0)
    {
      return false;
    }
  return true;
}
} // namespace

std::vector<int> primelist(int l, int r)
{
  validateBounds(l, r);
  std::vector<int> result;
  for(int n = std::max(l, 2); ; ++n)
  {
    if(isprime(n))
    {
      result.push_back(n);
    }
    // Test before incrementing so r == INT_MAX does not overflow.
    if(n == r)
    {
      break;
    }
  }
  return result;
}
