TEMPLATE = subdirs
SUBDIRS += primelistlib primelist primelist_gui primelist_tests

primelistlib.subdir = primelistlib
primelist.subdir = primelist
primelist_gui.subdir = primelist_gui

# qmake expresses these dependencies in Makefiles used by Qt Creator.
primelist.depends = primelistlib
primelist_gui.depends = primelistlib

primelist_tests.subdir = primelist_tests
primelist_tests.depends = primelistlib
