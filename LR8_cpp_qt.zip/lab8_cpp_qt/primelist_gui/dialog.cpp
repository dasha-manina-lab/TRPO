#include <QMessageBox>
#include <stdexcept>
#include "dialog.h"
#include "ui_dialog.h"
#include "primelistlib.h"

namespace
{
int parseInteger(const QString &input, const char * parameter)
{
  const QString text = input.trimmed();
  bool ok = false;
  const int value = text.toInt(&ok, 10);
  if(!ok)
  {
    const QString reason = text.isEmpty()
                           ? QString::fromUtf8("поле пустое")
                           : QString::fromUtf8("значение не является десятичным целым числом или выходит за диапазон int");
    const QString message = QString::fromUtf8("Параметр %1 введён неверно: %2.")
                            .arg(QString::fromLatin1(parameter), reason);
    throw std::invalid_argument(message.toUtf8().constData());
  }
  return value;
}
} // namespace

Dialog::Dialog(QWidget *parent)
  : QDialog(parent)
  , ui(new Ui::Dialog)
{
  ui->setupUi(this);
}

Dialog::~Dialog()
{
  delete ui;
}

void Dialog::calculate()
{
  try
  {
    ui->listWidget->clear();
    const int a = parseInteger(ui->lineEditA->text(), "A");
    const int b = parseInteger(ui->lineEditB->text(), "B");
    for(int n : primelist(a, b))
    {
      ui->listWidget->addItem(QString::number(n));
    }
  }
  catch(const std::exception &e)
  {
    QMessageBox::critical(this, tr("Ошибка"), QString::fromUtf8(e.what()));
  }
  catch(...)
  {
    QMessageBox::critical(this, tr("Ошибка"), tr("Неизвестная ошибка обработки данных."));
  }
}
