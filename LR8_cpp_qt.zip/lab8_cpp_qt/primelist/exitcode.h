#ifndef EXITCODE_H
#define EXITCODE_H

// The existing LR5 category values are preserved; code 4 is a defensive fallback.
enum class ExitCode : int
{
  Success = 0,
  InvalidArguments = 1,
  InvalidNumber = 2,
  InvalidRange = 3,
  UnexpectedError = 4
};

constexpr int exitStatus(ExitCode code) noexcept
{
  return static_cast<int>(code);
}

#endif // EXITCODE_H
