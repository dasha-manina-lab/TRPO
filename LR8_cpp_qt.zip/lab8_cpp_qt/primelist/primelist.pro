TEMPLATE = app
TARGET = primelist
CONFIG += console c++17 debug_and_release build_all
CONFIG -= app_bundle qt

SOURCES += main.cpp
include(../primelistlib/link_primelistlib.pri)

CONFIG(debug, debug|release) {
    DESTDIR = $$OUT_PWD/debug
    OBJECTS_DIR = $$OUT_PWD/.obj/debug
} else {
    DESTDIR = $$OUT_PWD/release
    OBJECTS_DIR = $$OUT_PWD/.obj/release
}

DISTFILES += .astylerc .gitattributes .githooks/pre-commit .githooks/format-all.sh .githooks/install.sh .githooks/install.ps1

HEADERS += exitcode.h
