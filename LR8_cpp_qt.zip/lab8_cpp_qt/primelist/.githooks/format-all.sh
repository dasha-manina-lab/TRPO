#!/usr/bin/env bash
# Process every tracked C/C++ source, including sources not originally staged.
# --worktree formats without staging. The default mode is used by pre-commit.
set -euo pipefail
fail() { printf 'AStyle: %s\n' "$*" >&2; exit 1; }
root=$(git rev-parse --show-toplevel) || exit 1
cd "$root"
mode=${1:-commit}
[[ "$mode" == commit || "$mode" == --worktree ]] || fail 'Unknown argument.'
[[ -f .astylerc ]] || fail 'Missing versioned .astylerc.'

formatter=${ASTYLE:-}
if [[ -z "$formatter" ]]; then
  formatter=$(git config --local --get formatter.astyle || true)
fi
if [[ -z "$formatter" ]]; then
  for command_name in astyle AStyle astyle.exe AStyle.exe; do
    if command -v "$command_name" >/dev/null 2>&1; then
      formatter=$(command -v "$command_name")
      break
    fi
  done
fi
if [[ -z "$formatter" ]]; then
  case "${OSTYPE:-}" in
    msys*|cygwin*|win32*)
      for candidate in "$root/tools/astyle/AStyle.exe" "$root/../tools/astyle/AStyle.exe"; do
        if [[ -f "$candidate" ]]; then formatter=$candidate; break; fi
      done
      ;;
  esac
fi
[[ -n "$formatter" ]] || fail 'AStyle not found. Run .githooks/install.ps1 or .githooks/install.sh with its path.'


files=()
while IFS= read -r -d '' file; do
  [[ -f "$file" ]] && files+=("$file")
done < <(git ls-files -z -- '*.cpp' '*.h' '*.hpp' '*.cc' '*.cxx' '*.hh' '*.hxx')
if [[ ${#files[@]} -eq 0 ]]; then exit 0; fi

configs=()
for file in "${files[@]}"; do
  config=.astylerc
  directory=$(dirname "$file")
  while [[ "$directory" != . ]]; do
    if [[ -f "$directory/.astylerc" ]]; then config=$directory/.astylerc; break; fi
    directory=$(dirname "$directory")
  done
  configs+=("$config")
done

if [[ "$mode" == commit ]]; then
  for config in "${configs[@]}"; do
    git cat-file -e ":$config" 2>/dev/null || fail "Stage $config before committing."
    git diff --quiet -- "$config" || fail "Unstaged changes in $config. Stage them or restore them first."
  done
  # Check everything before touching any source. Never stage unrelated edits silently.
  for file in "${files[@]}"; do
    [[ -z "$(git ls-files --unmerged -- "$file")" ]] || fail "Resolve the merge conflict in: $file"
    git diff --quiet -- "$file" || fail "Unstaged source edits in '$file'. Stage all intended source edits before committing; nothing was formatted."
  done
fi

for index in "${!files[@]}"; do
  file=${files[$index]}
  config=${configs[$index]}
  "$formatter" --options="$root/$config" --project=none --suffix=none --quiet "$root/$file" || fail "Formatting failed: $file. Commit cancelled; index not updated."
done
if [[ "$mode" == commit ]]; then
  git add -- "${files[@]}"
fi
printf 'AStyle: processed %s tracked C/C++ files using .astylerc.\n' "${#files[@]}"
