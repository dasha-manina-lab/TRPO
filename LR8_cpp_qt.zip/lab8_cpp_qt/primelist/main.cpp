#include "exitcode.h"
#include "primelistlib.h"

#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>

namespace
{
std::invalid_argument invalidNumber(const char * name)
{
  return std::invalid_argument(std::string("Invalid ") + name
                               + ": enter a decimal integer in the int range.");
}

int parseInteger(const std::string &text, const char * name)
{
  const auto first = text.find_first_not_of(" \t\r\n");
  if(first == std::string::npos)
  {
    throw invalidNumber(name);
  }
  const auto last = text.find_last_not_of(" \t\r\n");
  const std::string value = text.substr(first, last - first + 1);
  const std::size_t start = (value[0] == '+' || value[0] == '-') ? 1 : 0;
  if(start == value.size())
  {
    throw invalidNumber(name);
  }
  for(std::size_t i = start; i < value.size(); ++i)
  {
    if(value[i] < '0' || value[i] > '9')
    {
      throw invalidNumber(name);
    }
  }
  try
  {
    const long long number = std::stoll(value, nullptr, 10);
    if(number < std::numeric_limits<int>::min()
        || number > std::numeric_limits<int>::max())
    {
      throw invalidNumber(name);
    }
    return static_cast<int>(number);
  }
  catch(const std::out_of_range &)
  {
    // Overflow while parsing is a representation/type error, not a bounds error.
    throw invalidNumber(name);
  }
}
} // namespace

int main(int argc, char * argv[])
{
  try
  {
    if(argc != 3)
    {
      throw std::length_error("Expected exactly two parameters. Usage: primelist A B");
    }
    const int a = parseInteger(argv[1], "A");
    const int b = parseInteger(argv[2], "B");
    const auto numbers = primelist(a, b);
    if(numbers.empty())
    {
      std::cout << "No prime numbers in the interval.\n";
    }
    else
    {
      for(std::size_t i = 0; i < numbers.size(); ++i)
      {
        std::cout << (i == 0 ? "" : " ") << numbers[i];
      }
      std::cout << '\n';
    }
    return exitStatus(ExitCode::Success);
  }
  catch(const std::length_error &e)
  {
    std::cerr << e.what() << '\n';
    return exitStatus(ExitCode::InvalidArguments);
  }
  catch(const std::invalid_argument &e)
  {
    std::cerr << e.what() << '\n';
    return exitStatus(ExitCode::InvalidNumber);
  }
  catch(const std::out_of_range &e)
  {
    std::cerr << e.what() << '\n';
    return exitStatus(ExitCode::InvalidRange);
  }
  catch(const std::exception &e)
  {
    std::cerr << "Unexpected error: " << e.what() << '\n';
    return exitStatus(ExitCode::UnexpectedError);
  }
  catch(...)
  {
    std::cerr << "Unexpected non-standard exception.\n";
    return exitStatus(ExitCode::UnexpectedError);
  }
}

static_assert(1 + 1 == 2, "LR6 formatting check");
