TEMPLATE = app
TARGET = primelist_tests
QT += core testlib
QT -= gui
CONFIG += console testcase c++17 debug_and_release build_all
CONFIG -= app_bundle

SOURCES += tst_primelist.cpp
include(../primelistlib/link_primelistlib.pri)
DISTFILES += .astylerc

CONFIG(debug, debug|release) {
    DESTDIR = $$OUT_PWD/debug
    OBJECTS_DIR = $$OUT_PWD/.obj/debug
    MOC_DIR = $$OUT_PWD/.moc/debug
} else {
    DESTDIR = $$OUT_PWD/release
    OBJECTS_DIR = $$OUT_PWD/.obj/release
    MOC_DIR = $$OUT_PWD/.moc/release
}
