#include <QtTest>
#include "primelistlib.h"

#include <algorithm>
#include <chrono>
#include <climits>
#include <stdexcept>
#include <typeinfo>
#include <vector>

namespace
{
std::vector<int> referencePrimes(int lower, int upper)
{
  // Independent reference: sieve, rather than the library's trial division.
  std::vector<bool> composite(static_cast<std::size_t>(upper) + 1, false);
  for(int p = 2; p <= upper / p; ++p)
  {
    if(!composite[p])
    {
      for(int n = p * p; n <= upper; n += p)
      {
        composite[n] = true;
      }
    }
  }
  std::vector<int> expected;
  for(int n = std::max(lower, 2); n <= upper; ++n)
  {
    if(!composite[n])
    {
      expected.push_back(n);
    }
  }
  return expected;
}
} // namespace

class PrimeListTests : public QObject
{
  Q_OBJECT
private:
  std::vector<int> fiveDigitReference_;
  void expectRangeError(int lower, int upper, const char * message);

private slots:
  void initTestCase();
  void cleanupTestCase();
  void oneIsNotPrime();
  void returnsOnlyAndAllPrimes();
  void includesLowerPrimeBoundary();
  void includesUpperPrimeBoundary();
  void includesBothPrimeBoundaries();
  void excludesCompositeBoundaries();
  void noPrimesInValidRange();
  void handlesMaximumIntBoundary();
  void rejectsZeroLower();
  void rejectsNegativeLower();
  void rejectsMinimumIntLower();
  void rejectsZeroUpper();
  void rejectsNegativeUpper();
  void rejectsMinimumIntUpper();
  void rejectsReversedBounds();
  void rejectsEqualBounds();
  void rejectsEqualMaximumIntBounds();
  void allFiveDigitPrimesWithin100ms();
  void benchmarkFiveDigitPrimes();
};

void PrimeListTests::initTestCase()
{
  // Build and validate reference outside the measured function call.
  fiveDigitReference_ = referencePrimes(10000, 99999);
  QCOMPARE(static_cast<int>(fiveDigitReference_.size()), 8363);
  QCOMPARE(fiveDigitReference_.front(), 10007);
  QCOMPARE(fiveDigitReference_.back(), 99991);
}

void PrimeListTests::cleanupTestCase()
{
  fiveDigitReference_.clear();
}

void PrimeListTests::oneIsNotPrime()
{
  const std::vector<int> expected{2};
  QCOMPARE(primelist(1, 2), expected);
}

void PrimeListTests::returnsOnlyAndAllPrimes()
{
  const auto expected = referencePrimes(1, 2000);
  const auto actual = primelist(1, 2000);
  QCOMPARE(actual, expected);
}

void PrimeListTests::includesLowerPrimeBoundary()
{
  const std::vector<int> expected{11, 13, 17, 19};
  QCOMPARE(primelist(11, 20), expected);
}

void PrimeListTests::includesUpperPrimeBoundary()
{
  const std::vector<int> expected{11, 13};
  QCOMPARE(primelist(8, 13), expected);
}

void PrimeListTests::includesBothPrimeBoundaries()
{
  const std::vector<int> expected{2, 3, 5, 7};
  QCOMPARE(primelist(2, 7), expected);
}

void PrimeListTests::excludesCompositeBoundaries()
{
  const std::vector<int> expected{5, 7};
  QCOMPARE(primelist(4, 10), expected);
}

void PrimeListTests::noPrimesInValidRange()
{
  const std::vector<int> expected;
  QCOMPARE(primelist(14, 16), expected);
}

void PrimeListTests::handlesMaximumIntBoundary()
{
  const std::vector<int> expected{INT_MAX};
  QCOMPARE(primelist(INT_MAX - 1, INT_MAX), expected);
}

void PrimeListTests::expectRangeError(int lower, int upper, const char * message)
{
  try
  {
    (void)primelist(lower, upper);
    QFAIL("Expected std::out_of_range, but no exception was thrown.");
  }
  catch(const std::out_of_range &error)
  {
    QVERIFY2(typeid(error) == typeid(std::out_of_range), "The dynamic exception type is incorrect.");
    QCOMPARE(QString::fromUtf8(error.what()), QString::fromLatin1(message));
  }
  catch(const std::exception &error)
  {
    const QByteArray details = QByteArray("Wrong standard exception: ") + error.what();
    QFAIL(details.constData());
  }
  catch(...)
  {
    QFAIL("Wrong non-standard exception type.");
  }
}

void PrimeListTests::rejectsZeroLower()
{
  expectRangeError(0, 20, "Invalid A: the lower bound must be a natural number (A >= 1).");
}

void PrimeListTests::rejectsNegativeLower()
{
  expectRangeError(-5, 20, "Invalid A: the lower bound must be a natural number (A >= 1).");
}

void PrimeListTests::rejectsMinimumIntLower()
{
  expectRangeError(INT_MIN, 20, "Invalid A: the lower bound must be a natural number (A >= 1).");
}

void PrimeListTests::rejectsZeroUpper()
{
  expectRangeError(1, 0, "Invalid B: the upper bound must be a natural number (B >= 1).");
}

void PrimeListTests::rejectsNegativeUpper()
{
  expectRangeError(1, -5, "Invalid B: the upper bound must be a natural number (B >= 1).");
}

void PrimeListTests::rejectsMinimumIntUpper()
{
  expectRangeError(1, INT_MIN, "Invalid B: the upper bound must be a natural number (B >= 1).");
}

void PrimeListTests::rejectsReversedBounds()
{
  expectRangeError(20, 1, "Invalid B: the upper bound must be strictly greater than A.");
}

void PrimeListTests::rejectsEqualBounds()
{
  expectRangeError(2, 2, "Invalid B: the upper bound must be strictly greater than A.");
}

void PrimeListTests::rejectsEqualMaximumIntBounds()
{
  expectRangeError(INT_MAX, INT_MAX, "Invalid B: the upper bound must be strictly greater than A.");
}

void PrimeListTests::allFiveDigitPrimesWithin100ms()
{
  const auto started = std::chrono::steady_clock::now();
  const auto actual = primelist(10000, 99999);
  const auto elapsed = std::chrono::steady_clock::now() - started;
  const double milliseconds = std::chrono::duration<double, std::milli>(elapsed).count();
  // Validate the entire list as well as the duration, not just its size.
  QCOMPARE(actual, fiveDigitReference_);
  QCOMPARE(static_cast<int>(actual.size()), 8363);
  const QByteArray details = QString("Five-digit primes: %1 ms; limit: 100 ms.")
                             .arg(milliseconds, 0, 'f', 3).toLatin1();
  qInfo("%s", details.constData());
  QVERIFY2(elapsed <= std::chrono::milliseconds(100), details.constData());
}

void PrimeListTests::benchmarkFiveDigitPrimes()
{
  std::vector<int> actual;
  QBENCHMARK
  {
    actual = primelist(10000, 99999);
  }
  QCOMPARE(actual, fiveDigitReference_);
}

QTEST_APPLESS_MAIN(PrimeListTests)
#include "tst_primelist.moc"
