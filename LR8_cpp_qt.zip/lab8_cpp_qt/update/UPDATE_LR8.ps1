param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectRoot
)
$ErrorActionPreference = 'Stop'
$null = Get-Command git -ErrorAction Stop
$root = (Resolve-Path -LiteralPath $ProjectRoot).Path
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw | ConvertFrom-Json
function Git-Checked {
    param([string]$Repo, [string[]]$GitArgs)
    & git -C $Repo @GitArgs
    if ($LASTEXITCODE -ne 0) { throw ('Git failed: ' + ($GitArgs -join ' ')) }
}
if (-not (Test-Path -LiteralPath (Join-Path $root 'lab4.pro'))) {
    throw 'ProjectRoot must contain your existing lab4.pro.'
}
# Check all working copies and all offline bundles before updating any repository.
foreach ($entry in $manifest.repositories) {
    $repo = Join-Path $root $entry.folder
    if (-not (Test-Path -LiteralPath (Join-Path $repo '.git'))) { throw ('Missing Git repository: ' + $repo) }
    $branch = (Git-Checked -Repo $repo -GitArgs @('branch', '--show-current')).Trim()
    if ($branch -ne $entry.branch) { throw ('Switch to ' + $entry.branch + ' in ' + $repo + ' first.') }
    $status = @(Git-Checked -Repo $repo -GitArgs @('status', '--porcelain'))
    if ($status.Count -gt 0) { throw ('Uncommitted changes in ' + $repo + '. Save them before updating; no working files were changed.') }
    $head = (Git-Checked -Repo $repo -GitArgs @('rev-parse', 'HEAD')).Trim()
    if ($head -ne $entry.base -and $head -ne $entry.target) {
        throw ('The current history differs from the uploaded LR7 archive in ' + $repo + '. Stop and supply the current archive; do not reset your commits.')
    }
    if ($entry.exceptions) {
        & git -C $repo show-ref --verify --quiet refs/heads/exceptions
        $exists = $LASTEXITCODE
        if ($exists -eq 0) {
            $exceptionHead = (Git-Checked -Repo $repo -GitArgs @('rev-parse', 'exceptions')).Trim()
            if ($exceptionHead -ne $entry.exceptions) { throw ('An unrelated exceptions branch already exists in ' + $repo) }
        } elseif ($exists -ne 1) { throw 'Cannot inspect the exceptions branch.' }
    }
    $bundle = Join-Path $PSScriptRoot $entry.bundle
    if ((Get-FileHash -LiteralPath $bundle -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw ('Bundle checksum mismatch: ' + $bundle) }
    Git-Checked -Repo $repo -GitArgs @('bundle', 'verify', $bundle)
}

foreach ($entry in $manifest.repositories) {
    $repo = Join-Path $root $entry.folder
    $head = (Git-Checked -Repo $repo -GitArgs @('rev-parse', 'HEAD')).Trim()
    $bundle = Join-Path $PSScriptRoot $entry.bundle
    $specs = @('refs/heads/main:refs/lab8/import-main')
    if ($entry.exceptions) { $specs += 'refs/heads/exceptions:refs/heads/exceptions' }
    if ($head -ne $entry.target) {
        Git-Checked -Repo $repo -GitArgs (@('fetch', '--no-tags', $bundle) + $specs)
        Git-Checked -Repo $repo -GitArgs @('merge', '--ff-only', 'refs/lab8/import-main')
    } else {
        Write-Host ('Already updated: ' + $repo)
    }
    # Preserve the repositories and personal Qt Creator settings. No .git replacement.
    Git-Checked -Repo $repo -GitArgs @('config', '--local', 'core.filemode', 'false')
    if ($entry.exceptions) {
        Git-Checked -Repo $repo -GitArgs @('config', '--local', 'core.hooksPath', '.githooks')
        $tool = Join-Path $root 'tools/astyle/AStyle.exe'
        if (Test-Path -LiteralPath $tool) { Git-Checked -Repo $repo -GitArgs @('config', '--local', 'formatter.astyle', $tool.Replace('\', '/')) }
        Git-Checked -Repo $repo -GitArgs @('config', '--local', 'merge.tool', 'meld')
        Git-Checked -Repo $repo -GitArgs @('config', '--local', 'mergetool.keepbackup', 'false')
    }
    Git-Checked -Repo $repo -GitArgs @('update-ref', '-d', 'refs/lab8/import-main')
    $actual = (Git-Checked -Repo $repo -GitArgs @('rev-parse', 'HEAD')).Trim()
    if ($actual -ne $entry.target) { throw ('Unexpected HEAD after update: ' + $repo) }
}
foreach ($entry in $manifest.repositories) {
    $repo = Join-Path $root $entry.folder
    $status = @(Git-Checked -Repo $repo -GitArgs @('status', '--porcelain'))
    if ($status.Count -gt 0) { throw ('Check the remaining changes in ' + $repo) }
    Write-Host ('Verified clean: ' + $repo)
}
Write-Host 'LR8 update completed. Open your existing lab4.pro, build Release, then run primelist_tests.'
Write-Host 'LR7 exception branches and LR6 formatting hooks are preserved. The sample project is separate from the passing library suite.'
