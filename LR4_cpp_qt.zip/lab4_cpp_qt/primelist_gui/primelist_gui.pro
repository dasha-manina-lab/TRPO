TEMPLATE = app
TARGET = primelist_gui
QT += core gui widgets
CONFIG += c++17 debug_and_release build_all

SOURCES += main.cpp dialog.cpp
HEADERS += dialog.h
FORMS += dialog.ui
include(../primelistlib/link_primelistlib.pri)

CONFIG(debug, debug|release) {
    DESTDIR = $$OUT_PWD/debug
    OBJECTS_DIR = $$OUT_PWD/.obj/debug
    MOC_DIR = $$OUT_PWD/.moc/debug
    UI_DIR = $$OUT_PWD/.ui/debug
    RCC_DIR = $$OUT_PWD/.rcc/debug
} else {
    DESTDIR = $$OUT_PWD/release
    OBJECTS_DIR = $$OUT_PWD/.obj/release
    MOC_DIR = $$OUT_PWD/.moc/release
    UI_DIR = $$OUT_PWD/.ui/release
    RCC_DIR = $$OUT_PWD/.rcc/release
}
