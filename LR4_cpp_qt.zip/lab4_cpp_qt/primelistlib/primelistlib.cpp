#include "primelistlib.h"

#include <algorithm>

namespace {
bool isprime(int n)
{
    if (n < 2)
        return false;
    // Division avoids overflow in i * i for large int values.
    for (int i = 2; i <= n / i; ++i)
        if (n % i == 0)
            return false;
    return true;
}
} // namespace

std::vector<int> primelist(int l, int r)
{
    std::vector<int> result;
    if (l > r || r < 2)
        return result;
    for (int n = std::max(l, 2); ; ++n) {
        if (isprime(n))
            result.push_back(n);
        // Test before incrementing so r == INT_MAX does not overflow.
        if (n == r)
            break;
    }
    return result;
}
