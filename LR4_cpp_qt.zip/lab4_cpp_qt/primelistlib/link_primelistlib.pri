# Applications are siblings of primelistlib in both source and shadow builds.
INCLUDEPATH += $$PWD
DEPENDPATH += $$PWD

CONFIG(debug, debug|release) {
    PRIMELIST_LIB_DIR = $$clean_path($$OUT_PWD/../primelistlib/debug)
} else {
    PRIMELIST_LIB_DIR = $$clean_path($$OUT_PWD/../primelistlib/release)
}
LIBS += -L$$quote($$PRIMELIST_LIB_DIR) -lprimelistlib

win32-msvc* {
    PRE_TARGETDEPS += $$quote($$PRIMELIST_LIB_DIR/primelistlib.lib)
} else {
    PRE_TARGETDEPS += $$quote($$PRIMELIST_LIB_DIR/libprimelistlib.a)
}
