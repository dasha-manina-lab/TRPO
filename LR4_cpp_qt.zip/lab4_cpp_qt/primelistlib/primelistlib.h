#ifndef PRIMELISTLIB_H
#define PRIMELISTLIB_H

#include <vector>

// Return all prime numbers in the closed interval [l, r].
// An empty or reversed interval produces an empty vector.
std::vector<int> primelist(int l, int r);

#endif // PRIMELISTLIB_H
