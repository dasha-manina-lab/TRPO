TEMPLATE = subdirs
SUBDIRS += primelistlib primelist primelist_gui

primelistlib.subdir = primelistlib
primelist.subdir = primelist
primelist_gui.subdir = primelist_gui

# qmake expresses these dependencies in Makefiles used by Qt Creator.
primelist.depends = primelistlib
primelist_gui.depends = primelistlib
