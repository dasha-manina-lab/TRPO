#include <QMessageBox>
#include "dialog.h"
#include "ui_dialog.h"
#include "primelistlib.h"

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::calculate()
{
    ui->listWidget->clear();

    QString textA = ui->lineEditA->text().trimmed();
    QString textB = ui->lineEditB->text().trimmed();

    bool okA = false;
    bool okB = false;
    int a = textA.toInt(&okA, 10);
    int b = textB.toInt(&okB, 10);

    if (!okA) {
        QString reason = textA.isEmpty()
        ? "поле пустое"
        : "значение не является десятичным целым числом или выходит за диапазон int";
        QMessageBox::critical(this, "Ошибка",
                              "Параметр A введён неверно: " + reason + ".");
        return;
    }
    if (!okB) {
        QString reason = textB.isEmpty()
        ? "поле пустое"
        : "значение не является десятичным целым числом или выходит за диапазон int";
        QMessageBox::critical(this, "Ошибка",
                              "Параметр B введён неверно: " + reason + ".");
        return;
    }

    if (a <= 0) {
        QMessageBox::critical(this, "Ошибка",
                              "Параметр A введён неверно: нижняя граница должна быть "
                              "натуральным числом (не меньше 1).");
        return;
    }
    if (b <= 0) {
        QMessageBox::critical(this, "Ошибка",
                              "Параметр B введён неверно: верхняя граница должна быть "
                              "натуральным числом (не меньше 1).");
        return;
    }
    if (b <= a) {
        QMessageBox::critical(this, "Ошибка",
                              "Параметр B введён неверно: верхняя граница должна быть "
                              "строго больше нижней границы A.");
        return;
    }

    for (int n : primelist(a, b)) {
        ui->listWidget->addItem(QString::number(n));
    }
}
