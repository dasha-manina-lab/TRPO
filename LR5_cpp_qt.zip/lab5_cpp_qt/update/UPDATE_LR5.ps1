param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectRoot
)
$ErrorActionPreference = 'Stop'
$null = Get-Command git -ErrorAction Stop
$root = (Resolve-Path -LiteralPath $ProjectRoot).Path

function Run-Git {
    param([string]$Repo, [string[]]$GitArgs)
    & git -C $Repo @GitArgs
    if ($LASTEXITCODE -ne 0) {
        throw ('Git failed: ' + ($GitArgs -join ' '))
    }
}

if (-not (Test-Path -LiteralPath (Join-Path $root 'lab4.pro'))) {
    throw 'ProjectRoot must be the directory containing lab4.pro.'
}
# Check all repositories before changing any files. Never replace .git folders.
foreach ($relative in @('.', 'primelist', 'primelist_gui')) {
    $repo = Join-Path $root $relative
    if (-not (Test-Path -LiteralPath (Join-Path $repo '.git'))) {
        throw ('Missing local Git repository: ' + $repo)
    }
    $status = @(Run-Git -Repo $repo -GitArgs @('status', '--porcelain'))
    if ($status.Count -gt 0) {
        throw ('Uncommitted changes in ' + $repo + '. Commit them first; no files were changed.')
    }
    $name = Run-Git -Repo $repo -GitArgs @('config', 'user.name')
    $email = Run-Git -Repo $repo -GitArgs @('config', 'user.email')
    if (-not $name -or -not $email) {
        throw ('Configure Git user.name and user.email in ' + $repo)
    }
}

function Apply-Stage {
    param([string]$Source, [string]$RepoName, [string]$FileName, [string]$Message)
    $repo = Join-Path $root $RepoName
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $Source) -Destination (Join-Path $repo $FileName)
    Run-Git -Repo $repo -GitArgs @('add', '--', $FileName)
    & git -C $repo diff --cached --quiet
    if ($LASTEXITCODE -eq 1) {
        Run-Git -Repo $repo -GitArgs @('commit', '-m', $Message)
    } elseif ($LASTEXITCODE -ne 0) {
        throw ('Could not inspect staged changes in ' + $repo)
    }
}

$consoleFinal = Join-Path $PSScriptRoot 'stages/03_range/main.cpp'
$guiFinal = Join-Path $PSScriptRoot 'stages/04_gui/dialog.cpp'
$consoleCurrent = Join-Path $root 'primelist/main.cpp'
$guiCurrent = Join-Path $root 'primelist_gui/dialog.cpp'
$alreadyUpdated = ((Get-FileHash -LiteralPath $consoleFinal).Hash -eq (Get-FileHash -LiteralPath $consoleCurrent).Hash) -and
                  ((Get-FileHash -LiteralPath $guiFinal).Hash -eq (Get-FileHash -LiteralPath $guiCurrent).Hash)
if (-not $alreadyUpdated) {
    Apply-Stage 'stages/01_batch/main.cpp' 'primelist' 'main.cpp' 'LR5 stage 1: use batch mode with two command-line parameters'
    Apply-Stage 'stages/02_decimal/main.cpp' 'primelist' 'main.cpp' 'LR5 stage 2: distinguish argument and decimal-number errors'
    Apply-Stage 'stages/03_range/main.cpp' 'primelist' 'main.cpp' 'LR5 stage 3: require natural bounds and B strictly greater than A'
    Apply-Stage 'stages/04_gui/dialog.cpp' 'primelist_gui' 'dialog.cpp' 'LR5 stage 4: validate natural bounds and their strict order in GUI dialogs'
} else {
    Write-Host 'Both applications already contain the final LR5 changes.'
}

# Keep the user's library (including local verification comments) and all Git history.
$package = Split-Path -Parent $PSScriptRoot
Copy-Item -LiteralPath (Join-Path $package 'README.md') -Destination (Join-Path $root 'README.md')
Copy-Item -LiteralPath (Join-Path $package 'REPORT.md') -Destination (Join-Path $root 'REPORT.md')
Run-Git -Repo $root -GitArgs @('add', '--', 'README.md', 'REPORT.md')
& git -C $root diff --cached --quiet
if ($LASTEXITCODE -eq 1) {
    Run-Git -Repo $root -GitArgs @('commit', '-m', 'Document LR5 batch mode and validation checks')
} elseif ($LASTEXITCODE -ne 0) {
    throw 'Could not inspect staged documentation changes.'
}
foreach ($relative in @('.', 'primelist', 'primelist_gui')) {
    Run-Git -Repo (Join-Path $root $relative) -GitArgs @('status', '--short')
}
Write-Host 'LR5 update completed. Open your existing lab4.pro in Qt Creator.'
