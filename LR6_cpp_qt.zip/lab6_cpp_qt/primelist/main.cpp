#include "primelistlib.h"

#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>

namespace
{
enum ExitCode
{
  Success = 0,
  InvalidArguments = 1,
  InvalidNumber = 2,
  InvalidRange = 3
};

bool parseInteger(const std::string &text, int & result)
{
  const auto first = text.find_first_not_of(" \t\r\n");
  if(first == std::string::npos)
  {
    return false;
  }
  const auto last = text.find_last_not_of(" \t\r\n");
  const std::string value = text.substr(first, last - first + 1);
  std::size_t pos = (value[0] == '+' || value[0] == '-') ? 1 : 0;
  if(pos == value.size())
  {
    return false;
  }
  for(std::size_t i = pos; i < value.size(); ++i)
    if(value[i] < '0' || value[i] > '9')
    {
      return false;
    }
  try
  {
    const long long number = std::stoll(value, nullptr, 10);
    if(number < std::numeric_limits<int>::min()
        || number > std::numeric_limits<int>::max())
    {
      return false;
    }
    result = static_cast<int>(number);
    return true;
  }
  catch(const std::exception &)
  {
    return false;
  }
}
} // namespace

int main(int argc, char * argv[])
{
  if(argc != 3)
  {
    std::cerr << "Expected exactly two parameters. Usage: primelist A B\n";
    return InvalidArguments;
  }
  const std::string textA = argv[1];
  const std::string textB = argv[2];
  int a = 0, b = 0;
  if(!parseInteger(textA, a))
  {
    std::cerr << "Invalid A: enter a decimal integer in the int range.\n";
    return InvalidNumber;
  }
  if(!parseInteger(textB, b))
  {
    std::cerr << "Invalid B: enter a decimal integer in the int range.\n";
    return InvalidNumber;
  }
  if(a <= 0)
  {
    std::cerr << "Invalid A: the lower bound must be a natural number (A >= 1).\n";
    return InvalidRange;
  }
  if(b <= 0)
  {
    std::cerr << "Invalid B: the upper bound must be a natural number (B >= 1).\n";
    return InvalidRange;
  }
  if(b <= a)
  {
    std::cerr << "Invalid B: the upper bound must be strictly greater than A.\n";
    return InvalidRange;
  }
  const auto numbers = primelist(a, b);
  if(numbers.empty())
  {
    std::cout << "No prime numbers in the interval.\n";
  }
  else
  {
    for(std::size_t i = 0; i < numbers.size(); ++i)
    {
      std::cout << (i == 0 ? "" : " ") << numbers[i];
    }
    std::cout << '\n';
  }
  return Success;
}
