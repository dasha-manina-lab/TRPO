param([string]$AStyleExe = '')
$ErrorActionPreference = 'Stop'
function Git-Checked {
    param([string[]]$GitArgs)
    & git -C $root @GitArgs
    if ($LASTEXITCODE -ne 0) { throw ('Git failed: ' + ($GitArgs -join ' ')) }
}
$root = Split-Path -Parent $PSScriptRoot
$old = & git -C $root config --local --get core.hooksPath
if ($LASTEXITCODE -gt 1) { throw 'Cannot read Git configuration.' }
if ($old -and $old -ne '.githooks') { throw ('Another hooksPath is configured: ' + $old) }
if (-not $old -and (Test-Path -LiteralPath (Join-Path $root '.git/hooks/pre-commit'))) {
    throw 'An existing pre-commit hook was found. Preserve/integrate it before installing.'
}
if (-not $AStyleExe) {
    foreach ($candidate in @((Join-Path $root 'tools/astyle/AStyle.exe'), (Join-Path (Split-Path -Parent $root) 'tools/astyle/AStyle.exe'))) {
        if (Test-Path -LiteralPath $candidate) { $AStyleExe = $candidate; break }
    }
}
if (-not $AStyleExe) {
    $command = Get-Command astyle.exe -ErrorAction SilentlyContinue
    if ($command) { $AStyleExe = $command.Source }
}
if (-not $AStyleExe) { throw 'Supply -AStyleExe with the full path to AStyle.exe.' }
$AStyleExe = (Resolve-Path -LiteralPath $AStyleExe).Path
& $AStyleExe --version
if ($LASTEXITCODE -ne 0) { throw 'AStyle could not start. Check the executable and Microsoft VC++ x64 runtime.' }
Git-Checked -GitArgs @('config', '--local', 'formatter.astyle', $AStyleExe.Replace('\', '/'))
Git-Checked -GitArgs @('config', '--local', 'core.hooksPath', '.githooks')
Write-Host ('Enabled versioned pre-commit hook in ' + $root)
