#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
cd "$root"
current=$(git config --local --get core.hooksPath || true)
if [[ -n "$current" && "$current" != .githooks ]]; then
  printf 'Another hooksPath is already configured: %s\n' "$current" >&2; exit 1
fi
if [[ -z "$current" && -f .git/hooks/pre-commit ]]; then
  printf 'An existing .git/hooks/pre-commit was found. Preserve/integrate it before installing.\n' >&2; exit 1
fi
if [[ -n "${1:-}" ]]; then
  "$1" --version
  git config --local formatter.astyle "$1"
fi
chmod +x .githooks/pre-commit .githooks/format-all.sh .githooks/install.sh
git config --local core.hooksPath .githooks
printf 'Enabled versioned pre-commit hook in %s\n' "$root"
