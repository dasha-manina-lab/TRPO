param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectRoot,
    [string]$AStyleExe = ''
)
$ErrorActionPreference = 'Stop'
$null = Get-Command git -ErrorAction Stop
$root = (Resolve-Path -LiteralPath $ProjectRoot).Path
$package = Split-Path -Parent $PSScriptRoot
$utf8 = New-Object System.Text.UTF8Encoding -ArgumentList $false
function Git-Checked {
    param([string]$Repo, [string[]]$GitArgs)
    & git -C $Repo @GitArgs
    if ($LASTEXITCODE -ne 0) { throw ('Git failed: ' + ($GitArgs -join ' ')) }
}
function Save-Text {
    param([string]$Path, [string]$Text)
    [System.IO.File]::WriteAllText($Path, $Text, $utf8)
}
function Add-StyleFilesToProject {
    param([string]$Path, [string]$Line)
    $text = [System.IO.File]::ReadAllText($Path)
    if (-not $text.Contains($Line)) { Save-Text $Path ($text.TrimEnd() + "`n`n" + $Line + "`n") }
}
function Add-BackupIgnore {
    param([string]$Repo)
    $path = Join-Path $Repo '.gitignore'
    $text = if (Test-Path -LiteralPath $path) { [System.IO.File]::ReadAllText($path) } else { '' }
    if (-not (($text -split "`r?`n") -contains '*.orig')) {
        Save-Text $path ($text.TrimEnd() + "`n`n# Artistic Style backups`n*.orig`n")
    }
}
function Commit-Changes {
    param([string]$Repo, [string]$Message)
    & git -C $Repo diff --cached --quiet
    if ($LASTEXITCODE -eq 1) {
        Git-Checked -Repo $Repo -GitArgs @('commit', '-m', $Message)
    } elseif ($LASTEXITCODE -ne 0) { throw 'Cannot inspect staged changes.' }
}
function Format-Library {
    $config = (Join-Path $root 'primelistlib/.astylerc').Replace('\', '/')
    $cpp = (Join-Path $root 'primelistlib/primelistlib.cpp').Replace('\', '/')
    $header = (Join-Path $root 'primelistlib/primelistlib.h').Replace('\', '/')
    & $AStyleExe ('--options=' + $config) '--project=none' '--suffix=none' '--quiet' $cpp $header
    if ($LASTEXITCODE -ne 0) { throw 'Library formatting failed.' }
}
function Can-ResumeInitialFormattingFailure {
    param([string]$Repo, [string[]]$Status)
    # Recognize ONLY files left by the old updater before its first failed AStyle call.
    # No reset, deletion, or implicit inclusion of unrelated user changes.
    & git -C $Repo diff --cached --quiet
    if ($LASTEXITCODE -ne 0) { return $false }
    foreach ($entry in $Status) {
        if ($entry.Length -lt 4) { return $false }
        $code = $entry.Substring(0, 2)
        $path = $entry.Substring(3)
        if ($path -eq 'primelistlib/primelistlib.pro' -and $code -eq ' M') {
            $original = ((Git-Checked -Repo $Repo -GitArgs @('show', 'HEAD:primelistlib/primelistlib.pro')) -join "`n").TrimEnd()
            $expected = $original + "`n`nDISTFILES += .astylerc"
            $actual = [System.IO.File]::ReadAllText((Join-Path $Repo $path)).Replace("`r`n", "`n").TrimEnd()
            if ($actual -ne $expected) { return $false }
        } elseif ($path -eq 'primelistlib/.astylerc' -and $code -eq '??') {
            $reference = Join-Path $PSScriptRoot 'styles/library-java.astylerc'
            if ((Get-FileHash -LiteralPath (Join-Path $Repo $path)).Hash -ne (Get-FileHash -LiteralPath $reference).Hash) { return $false }
        } elseif (($path -eq 'tools/astyle/LICENSE.md' -or $path -eq 'tools/astyle/ORIGIN.txt') -and $code -eq '??') {
            $reference = Join-Path $package $path
            if ((Get-FileHash -LiteralPath (Join-Path $Repo $path)).Hash -ne (Get-FileHash -LiteralPath $reference).Hash) { return $false }
        } else {
            return $false
        }
    }
    return $true
}
if (-not (Test-Path -LiteralPath (Join-Path $root 'lab4.pro'))) {
    throw 'ProjectRoot must contain your existing lab4.pro.'
}
if (Test-Path -LiteralPath (Join-Path $root 'formatting/LR6_VERSION')) {
    throw 'LR6 is already installed here. To activate hooks in a new copy, run its .githooks/install.ps1 instead.'
}
# Complete preflight before touching the working copy or enabling hooks.
foreach ($relative in @('.', 'primelist', 'primelist_gui')) {
    $repo = Join-Path $root $relative
    if (-not (Test-Path -LiteralPath (Join-Path $repo '.git'))) { throw ('Missing repository: ' + $repo) }
    $status = @(Git-Checked -Repo $repo -GitArgs @('status', '--porcelain', '--untracked-files=all'))
    if ($status.Count -gt 0) {
        if ($relative -eq '.' -and (Can-ResumeInitialFormattingFailure -Repo $repo -Status $status)) {
            Write-Host 'Recognized the old updater failure before the first library-formatting commit; resuming without discarding any files.'
        } else {
            throw ('Commit your existing changes first: ' + $repo + '. No project files changed.')
        }
    }
    $name = Git-Checked -Repo $repo -GitArgs @('config', 'user.name')
    $email = Git-Checked -Repo $repo -GitArgs @('config', 'user.email')
    if (-not $name -or -not $email) { throw ('Configure the Git author in: ' + $repo) }
    $oldHooks = & git -C $repo config --local --get core.hooksPath
    if ($LASTEXITCODE -gt 1) { throw 'Cannot inspect hooksPath.' }
    if ($oldHooks -or (Test-Path -LiteralPath (Join-Path $repo '.git/hooks/pre-commit')) -or (Test-Path -LiteralPath (Join-Path $repo '.githooks'))) {
        throw ('An existing hook configuration was found in ' + $repo + '. Preserve/integrate it before this installation.')
    }
}
if (-not $AStyleExe) { $AStyleExe = Join-Path $package 'tools/astyle/AStyle.exe' }
$AStyleExe = (Resolve-Path -LiteralPath $AStyleExe).Path
& $AStyleExe --version
if ($LASTEXITCODE -ne 0) { throw 'AStyle could not start. Check the Microsoft VC++ x64 runtime; do not disable Windows protection.' }
$toolDir = Join-Path $root 'tools/astyle'
$null = New-Item -ItemType Directory -Path $toolDir -Force
$destination = Join-Path $toolDir 'AStyle.exe'
if ([System.IO.Path]::GetFullPath($AStyleExe) -ne [System.IO.Path]::GetFullPath($destination)) {
    Copy-Item -LiteralPath $AStyleExe -Destination $destination
}
$AStyleExe = $destination
foreach ($name in @('LICENSE.md', 'ORIGIN.txt')) {
    Copy-Item -LiteralPath (Join-Path $package ('tools/astyle/' + $name)) -Destination (Join-Path $toolDir $name)
}

# Stage 1: library profile and formatting exactly as PDF section 2.
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'styles/library-java.astylerc') -Destination (Join-Path $root 'primelistlib/.astylerc')
Add-StyleFilesToProject (Join-Path $root 'primelistlib/primelistlib.pro') 'DISTFILES += .astylerc'
Format-Library
Git-Checked -Repo $root -GitArgs @('add', '--', 'primelistlib/.astylerc', 'primelistlib/primelistlib.pro', 'primelistlib/primelistlib.cpp', 'primelistlib/primelistlib.h')
Commit-Changes $root 'LR6 stage 1: format library with AStyle Java style and four-space indentation'

# Stage 2: switch the same library to the final PDF section 4 profile.
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'styles/library-bsd.astylerc') -Destination (Join-Path $root 'primelistlib/.astylerc')
Format-Library
Git-Checked -Repo $root -GitArgs @('add', '--', 'primelistlib/.astylerc', 'primelistlib/primelistlib.cpp', 'primelistlib/primelistlib.h')
Commit-Changes $root 'LR6 stage 2: switch library to BSD style and two-space indentation'

# Install tracked profiles and hooks. Only formatter settings/code layout change.
foreach ($relative in @('primelist', 'primelist_gui', '.')) {
    $repo = Join-Path $root $relative
    $source = Join-Path $package $relative
    foreach ($name in @('.astylerc', '.gitattributes')) {
        Copy-Item -LiteralPath (Join-Path $source $name) -Destination (Join-Path $repo $name)
    }
    Copy-Item -LiteralPath (Join-Path $source '.githooks') -Destination (Join-Path $repo '.githooks') -Recurse
    Add-BackupIgnore $repo
    $line = 'DISTFILES += .astylerc .gitattributes .githooks/pre-commit .githooks/format-all.sh .githooks/install.sh .githooks/install.ps1'
    if ($relative -eq '.') {
        Add-StyleFilesToProject (Join-Path $repo 'lab4.pro') $line
        foreach ($name in @('README.md', 'REPORT.md')) {
            Copy-Item -LiteralPath (Join-Path $package $name) -Destination (Join-Path $root $name)
        }
        $null = New-Item -ItemType Directory -Path (Join-Path $root 'formatting') -Force
        Save-Text (Join-Path $root 'formatting/LR6_VERSION') "1`n"
        Git-Checked -Repo $repo -GitArgs @('add', '--', '.astylerc', '.gitattributes', '.githooks', '.gitignore', 'lab4.pro', 'README.md', 'REPORT.md', 'formatting/LR6_VERSION', 'tools/astyle/LICENSE.md', 'tools/astyle/ORIGIN.txt')
    } else {
        $pro = $relative + '.pro'
        Add-StyleFilesToProject (Join-Path $repo $pro) $line
        Git-Checked -Repo $repo -GitArgs @('add', '--', '.astylerc', '.gitattributes', '.githooks', '.gitignore', $pro)
    }
    Git-Checked -Repo $repo -GitArgs @('update-index', '--chmod=+x', '.githooks/pre-commit', '.githooks/format-all.sh', '.githooks/install.sh')
    & (Join-Path $repo '.githooks/install.ps1') -AStyleExe $AStyleExe
    # pre-commit now formats ALL tracked sources and adds the results to this commit.
    Commit-Changes $repo 'LR6: version AStyle settings and format all sources before every commit'
}
foreach ($relative in @('.', 'primelist', 'primelist_gui')) {
    Git-Checked -Repo (Join-Path $root $relative) -GitArgs @('status', '--short')
}
Write-Host 'LR6 installed. Existing source comments, Git history and Qt Creator settings were preserved.'
Write-Host 'Finish the Beautifier setup in Qt Creator as described in README.md, then build your existing lab4.pro.'
